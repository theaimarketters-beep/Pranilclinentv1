# Pranil Client Lite — Minecraft Java 1.21.10

This is a **source project**, not a precompiled JAR. Build it in a cloud Java/Gradle environment (no Termux needed).

## Included starter features
- FPS counter and XYZ coordinates HUD
- Zoom toggle (C)
- Fullbright toggle (B)
- Toggle sprint (R)
- HUD toggle (H)
- Simple armor points readout
- Fabric client mod structure for Minecraft 1.21.10

## Build online (example: GitHub Codespaces)
1. Upload the entire ZIP contents to a GitHub repository.
2. Open the repository in Codespaces with a Java 21 environment.
3. In the terminal, run `gradle build` (or `./gradlew build` if a Gradle wrapper is added).
4. Download the JAR from `build/libs/PranilClient-1.0.0.jar` or the matching JAR filename in `build/libs`.
5. Put it in the `mods` folder used by Mojo Launcher.

## Important
- Install Fabric Loader for Minecraft 1.21.10 and a matching Fabric API.
- This starter project has not been compiled or tested in this environment. If the build fails, the dependency versions or mappings may need adjustment.
- The zoom implementation currently uses a fixed FOV and should be tested with your launcher.
- Armor HUD currently shows armor points as text; it does not yet draw individual armor icons.
- ReplayMod is intentionally not included.
