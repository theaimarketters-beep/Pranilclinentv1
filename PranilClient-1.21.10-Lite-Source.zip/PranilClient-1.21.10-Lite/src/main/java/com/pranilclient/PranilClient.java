package com.pranilclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class PranilClient implements ClientModInitializer {
    private static KeyBinding zoomKey, fullbrightKey, sprintKey, hudKey;
    private static boolean zoom = false, fullbright = false, autoSprint = false, showHud = true;
    private static double oldGamma = 1.0;

    @Override
    public void onInitializeClient() {
        zoomKey = key("key.pranilclient.zoom", GLFW.GLFW_KEY_C);
        fullbrightKey = key("key.pranilclient.fullbright", GLFW.GLFW_KEY_B);
        sprintKey = key("key.pranilclient.sprint", GLFW.GLFW_KEY_R);
        hudKey = key("key.pranilclient.hud", GLFW.GLFW_KEY_H);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (zoomKey.wasPressed()) zoom = !zoom;
            while (fullbrightKey.wasPressed()) {
                fullbright = !fullbright;
                if (client.options != null) {
                    if (fullbright) {
                        oldGamma = client.options.getGamma().getValue();
                        client.options.getGamma().setValue(16.0);
                    } else client.options.getGamma().setValue(oldGamma);
                }
                toast(client, "Fullbright " + (fullbright ? "ON" : "OFF"));
            }
            while (sprintKey.wasPressed()) {
                autoSprint = !autoSprint;
                toast(client, "Toggle Sprint " + (autoSprint ? "ON" : "OFF"));
            }
            while (hudKey.wasPressed()) {
                showHud = !showHud;
                toast(client, "Pranil HUD " + (showHud ? "ON" : "OFF"));
            }
            if (autoSprint && client.player != null && client.player.isOnGround()
                    && client.player.input.hasForwardMovement()) {
                client.player.setSprinting(true);
            }
            if (client.options != null) {
                client.options.getFov().setValue(zoom ? 30 : 70);
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (!showHud || client.player == null || client.world == null) return;
            int x = 6, y = 6;
            drawContext.drawText(client.textRenderer, "Pranil Client Lite", x, y, 0x55FF55, true);
            y += 12;
            drawContext.drawText(client.textRenderer, "FPS: " + client.getCurrentFps(), x, y, 0xFFFFFF, true);
            y += 12;
            drawContext.drawText(client.textRenderer,
                    String.format("XYZ: %.1f / %.1f / %.1f",
                            client.player.getX(), client.player.getY(), client.player.getZ()),
                    x, y, 0xFFFFFF, true);
            y += 12;
            if (client.player.getArmor() > 0) {
                drawContext.drawText(client.textRenderer,
                        "Armor: " + client.player.getArmor(), x, y, 0xFFFFFF, true);
            } else {
                drawContext.drawText(client.textRenderer, "Armor: 0", x, y, 0xAAAAAA, true);
            }
        });
    }

    private static KeyBinding key(String translationKey, int keyCode) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                translationKey, InputUtil.Type.KEYSYM, keyCode, KeyBinding.Category.MISC));
    }

    private static void toast(MinecraftClient client, String message) {
        if (client.player != null) client.player.sendMessage(Text.literal("[Pranil] " + message), true);
    }
}
